from flask import Flask, request, make_response

app = Flask(__name__)


def detect_crlf_injection(input_data):
    forbidden_pattern = r'[\r\n]'

    # Check if the input matches the forbidden pattern
    import re
    if re.search(forbidden_pattern, input_data):
        return True  # CRLF injection detected

    return False


@app.before_request
def before_request():
    for key, value in request.args.items():
        if detect_crlf_injection(value):
            print(f"CRLF injection detected in parameter '{key}' with value '{value}'")


@app.route('/')
def index():
    return 'Hello, and welcome Attacker!'


@app.route('/vulnerable_endpoint')
def vulnerable_endpoint():
    user_input = request.args.get('input', '')

    if detect_crlf_injection(user_input):
        injected_response = (
            'HTTP/1.1 200 OK\r\n'
            'Injected-Header: Malicious-Content\r\n'
            'Content-Type: text/html\r\n\r\n'
            '<html><body><h1>ALERT!!Injected Content</h1></body></html>'
        )
        return injected_response

    return 'Normal response: ' + user_input


@app.route('/additional_route')
def additional_route():
    user_input = request.args.get('input', '')

    if detect_crlf_injection(user_input):
        # If CRLF injection is detected, return another forged response
        another_injected_response = (
            'HTTP/1.1 200 OK\r\n'
            'Another-Injected-Header: More-Malicious-Content\r\n'
            'Content-Type: text/html\r\n\r\n'
            '<html><body><h1>BAM!!!Another Injected Content</h1></body></html>'
        )
        return another_injected_response

    # Otherwise, return a normal response
    return 'BOOM!! Another route!'

#http://127.0.0.1:5000/additional_route?input=normal%0AContent-Type:%20text/html


if __name__ == '__main__':
    app.run(debug=True)
